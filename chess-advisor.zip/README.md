# Chess Move Advisor

A small desktop app that opens a chess board. Type or click your opponent's
move, and it tells you the best move to play next.

## Quick start

```bash
git clone https://github.com/<your-username>/chess-advisor.git
cd chess-advisor
pip install -r requirements.txt
python chess_advisor.py
```

Requires Python 3.8+ with Tkinter (included with most Python installs; on
Debian/Ubuntu: `sudo apt install python3-tk`).

## How to use

1. Choose your colour when the game starts.
2. When it's the opponent's turn, enter their move by **clicking the board**
   or **typing it** (`e4`, `Nf3`, `O-O`, or `e2e4`) and pressing Enter.
3. When it's your turn, the recommended move appears as a blue arrow with
   an evaluation. Play it on your real board, then enter *your* move the same
   way (or press **Play suggestion**).
4. Repeat. Use **Undo** if you mistype, and **Flip** to turn the board.

## Stronger analysis with Stockfish (optional)

The app auto-detects [Stockfish](https://stockfishchess.org/download/) if it
is installed (`brew install stockfish`, `sudo apt install stockfish`, or
download the binary). Without it, a weaker built-in engine is used.

```bash
python chess_advisor.py --stockfish /path/to/stockfish --time 2
# or set STOCKFISH_PATH in your environment
```

The window title shows which engine is active.

## License

MIT
