#!/usr/bin/env python3
"""
Chess Move Advisor
------------------
Opens a chess board. Enter your opponent's moves (click the board or type
them) and the program tells you the best move to play next.

Uses Stockfish if it can find it; otherwise falls back to a built-in engine.
"""
import argparse
import os
import shutil
import threading
import tkinter as tk
from tkinter import messagebox, simpledialog

import chess
import chess.engine

SQ = 72  # square size in pixels
LIGHT, DARK = "#eeeed2", "#769656"
SELECT, SUGGEST, LAST = "#f6e05e", "#3b82f6", "#cdd26a"
GLYPHS = {"p": "♟", "n": "♞", "b": "♝", "r": "♜", "q": "♛", "k": "♚"}


# --------------------------------------------------------------------------
# Built-in fallback engine (alpha-beta search, used when Stockfish is absent)
# --------------------------------------------------------------------------
VALUES = {chess.PAWN: 100, chess.KNIGHT: 320, chess.BISHOP: 330,
          chess.ROOK: 500, chess.QUEEN: 900, chess.KING: 0}
MATE = 100000


def _centre(sq):
    f, r = chess.square_file(sq), chess.square_rank(sq)
    return int(3.5 - abs(3.5 - f)) + int(3.5 - abs(3.5 - r))


def evaluate(board):
    """Static score from the side-to-move's point of view."""
    total = 0
    for sq, piece in board.piece_map().items():
        v = VALUES[piece.piece_type]
        c = _centre(sq)
        if piece.piece_type in (chess.KNIGHT, chess.BISHOP):
            v += 10 * c
        elif piece.piece_type == chess.QUEEN:
            v += 2 * c
        elif piece.piece_type == chess.PAWN:
            rank = chess.square_rank(sq)
            advance = rank if piece.color == chess.WHITE else 7 - rank
            v += 8 * advance + 3 * c
        total += v if piece.color == board.turn else -v
    return total


def _order(board):
    def key(m):
        s = 0
        if board.is_capture(m):
            victim = board.piece_type_at(m.to_square) or chess.PAWN
            s += 10 * VALUES[victim] - VALUES[board.piece_type_at(m.from_square)]
        if m.promotion:
            s += 800
        if board.gives_check(m):
            s += 50
        return -s
    return sorted(board.legal_moves, key=key)


def _quiesce(board, alpha, beta, depth):
    stand = evaluate(board)
    if stand >= beta:
        return beta
    if depth == 0:
        return stand
    alpha = max(alpha, stand)
    for m in _order(board):
        if not board.is_capture(m):
            continue
        board.push(m)
        score = -_quiesce(board, -beta, -alpha, depth - 1)
        board.pop()
        if score >= beta:
            return beta
        alpha = max(alpha, score)
    return alpha


def _search(board, depth, alpha, beta, ply):
    if board.is_checkmate():
        return -MATE + ply
    if board.is_stalemate() or board.is_insufficient_material():
        return 0
    if depth == 0:
        return _quiesce(board, alpha, beta, 3)
    for m in _order(board):
        board.push(m)
        score = -_search(board, depth - 1, -beta, -alpha, ply + 1)
        board.pop()
        if score >= beta:
            return beta
        alpha = max(alpha, score)
    return alpha


def builtin_best(board, depth=3):
    board = board.copy()
    best, best_score, alpha = None, -10 * MATE, -10 * MATE
    for m in _order(board):
        board.push(m)
        score = -_search(board, depth - 1, -10 * MATE, -alpha, 1)
        board.pop()
        if score > best_score:
            best, best_score = m, score
        alpha = max(alpha, score)
    return best, best_score


def describe_cp(score):
    if abs(score) > MATE - 200:
        return "Forced mate found" if score > 0 else "You may be getting mated"
    return f"Evaluation: {score / 100:+.2f} (for you)"


# --------------------------------------------------------------------------
# Engine wrapper
# --------------------------------------------------------------------------
def find_stockfish(explicit=None):
    candidates = [explicit, os.environ.get("STOCKFISH_PATH"),
                  shutil.which("stockfish"),
                  "/usr/games/stockfish", "/usr/local/bin/stockfish",
                  "/opt/homebrew/bin/stockfish"]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return None


class Advisor:
    def __init__(self, stockfish_path=None, think_time=1.0):
        self.think_time = think_time
        self.lock = threading.Lock()
        self.engine = None
        path = find_stockfish(stockfish_path)
        if path:
            try:
                self.engine = chess.engine.SimpleEngine.popen_uci(path)
            except Exception:
                self.engine = None
        self.name = "Stockfish" if self.engine else "Built-in engine"

    def best(self, board):
        """Returns (move, human-readable evaluation text)."""
        with self.lock:
            if self.engine:
                info = self.engine.analyse(
                    board, chess.engine.Limit(time=self.think_time))
                move = info["pv"][0]
                s = info["score"].pov(board.turn)
                if s.is_mate():
                    n = s.mate()
                    text = (f"Mate in {n}" if n > 0
                            else f"Getting mated in {abs(n)}")
                else:
                    text = f"Evaluation: {s.score() / 100:+.2f} (for you)"
                return move, text
            move, score = builtin_best(board)
            return move, describe_cp(score)

    def close(self):
        if self.engine:
            try:
                self.engine.quit()
            except Exception:
                pass


# --------------------------------------------------------------------------
# GUI
# --------------------------------------------------------------------------
class App:
    def __init__(self, root, advisor):
        self.root, self.advisor = root, advisor
        self.board = chess.Board()
        self.my_color = chess.WHITE
        self.flipped = False
        self.selected = None
        self.suggestion = None
        self.token = 0  # invalidates stale analysis results

        root.title("Chess Move Advisor")
        root.protocol("WM_DELETE_WINDOW", self.quit)

        self.canvas = tk.Canvas(root, width=SQ * 8, height=SQ * 8,
                                highlightthickness=0)
        self.canvas.grid(row=0, column=0, columnspan=5, padx=10, pady=10)
        self.canvas.bind("<Button-1>", self.on_click)

        self.status = tk.Label(root, font=("Helvetica", 14, "bold"))
        self.status.grid(row=1, column=0, columnspan=5)
        self.advice = tk.Label(root, font=("Helvetica", 13), fg="#2563eb")
        self.advice.grid(row=2, column=0, columnspan=5, pady=(0, 6))

        tk.Label(root, text="Move (e.g. e4, Nf3, e2e4):").grid(
            row=3, column=0, sticky="e", padx=(10, 2))
        self.entry = tk.Entry(root, width=12, font=("Helvetica", 13))
        self.entry.grid(row=3, column=1, sticky="w")
        self.entry.bind("<Return>", lambda e: self.submit_text())
        tk.Button(root, text="Enter", command=self.submit_text).grid(
            row=3, column=2, sticky="w")

        bar = tk.Frame(root)
        bar.grid(row=4, column=0, columnspan=5, pady=8)
        for text, cmd in [("Play suggestion", self.play_suggestion),
                          ("Undo", self.undo), ("Flip", self.flip),
                          ("New game", self.new_game)]:
            tk.Button(bar, text=text, command=cmd).pack(side="left", padx=4)

        self.hist = tk.Label(root, wraplength=SQ * 8, justify="left",
                             fg="#666", font=("Helvetica", 10))
        self.hist.grid(row=5, column=0, columnspan=5, padx=10, pady=(0, 8))

        self.new_game(ask=True)

    # ---- drawing ---------------------------------------------------------
    def sq_xy(self, sq):
        f, r = chess.square_file(sq), chess.square_rank(sq)
        col = 7 - f if self.flipped else f
        row = r if self.flipped else 7 - r
        return col * SQ, row * SQ

    def draw(self):
        c = self.canvas
        c.delete("all")
        last = self.board.peek() if self.board.move_stack else None
        for sq in chess.SQUARES:
            x, y = self.sq_xy(sq)
            color = LIGHT if (chess.square_file(sq) + chess.square_rank(sq)) % 2 else DARK
            if last and sq in (last.from_square, last.to_square):
                color = LAST
            if sq == self.selected:
                color = SELECT
            c.create_rectangle(x, y, x + SQ, y + SQ, fill=color, outline="")
        for sq, p in self.board.piece_map().items():
            x, y = self.sq_xy(sq)
            white = p.color == chess.WHITE
            c.create_text(x + SQ / 2, y + SQ / 2, text=GLYPHS[p.symbol().lower()],
                          font=("Arial", int(SQ * 0.7)),
                          fill="white" if white else "black")
        if self.selected is not None:
            for m in self.board.legal_moves:
                if m.from_square == self.selected:
                    x, y = self.sq_xy(m.to_square)
                    c.create_oval(x + SQ * .36, y + SQ * .36, x + SQ * .64,
                                  y + SQ * .64, fill="#555", outline="")
        if self.suggestion:
            x1, y1 = self.sq_xy(self.suggestion.from_square)
            x2, y2 = self.sq_xy(self.suggestion.to_square)
            c.create_line(x1 + SQ / 2, y1 + SQ / 2, x2 + SQ / 2, y2 + SQ / 2,
                          fill=SUGGEST, width=8, arrow=tk.LAST,
                          arrowshape=(22, 26, 10), capstyle="round")
        self.hist.config(text=self.history_text())

    def history_text(self):
        b = chess.Board()
        out = []
        for i, m in enumerate(self.board.move_stack):
            if i % 2 == 0:
                out.append(f"{i // 2 + 1}.")
            out.append(b.san(m))
            b.push(m)
        return " ".join(out)

    # ---- game flow -------------------------------------------------------
    def refresh(self):
        self.token += 1
        self.suggestion = None
        self.advice.config(text="")
        b = self.board
        if b.is_game_over():
            self.status.config(text=f"Game over: {b.result()}")
        elif b.turn == self.my_color:
            self.status.config(text="Your move — thinking…")
            self.analyse()
        else:
            self.status.config(text="Opponent's turn — enter their move")
        self.draw()

    def analyse(self):
        token, board = self.token, self.board.copy()

        def work():
            try:
                move, text = self.advisor.best(board)
                san = board.san(move)
            except Exception as e:  # engine died, etc.
                self.root.after(0, lambda: self.advice.config(text=f"Engine error: {e}"))
                return
            self.root.after(0, lambda: self.show_suggestion(token, move, san, text))

        threading.Thread(target=work, daemon=True).start()

    def show_suggestion(self, token, move, san, text):
        if token != self.token:
            return
        self.suggestion = move
        self.status.config(text="Your move")
        self.advice.config(text=f"Play {san}   ({text})")
        self.draw()

    def push(self, move):
        self.board.push(move)
        self.selected = None
        self.refresh()

    def parse(self, text):
        text = text.strip()
        for fn in (self.board.parse_san, self.board.parse_uci):
            try:
                return fn(text)
            except ValueError:
                continue
        return None

    def submit_text(self):
        text = self.entry.get()
        if not text.strip():
            return
        move = self.parse(text)
        if move is None:
            messagebox.showerror("Illegal move",
                                 f"'{text}' isn't a legal move in this position.")
            return
        self.entry.delete(0, "end")
        self.push(move)

    def on_click(self, event):
        col, row = event.x // SQ, event.y // SQ
        if not (0 <= col < 8 and 0 <= row < 8):
            return
        f = 7 - col if self.flipped else col
        r = row if self.flipped else 7 - row
        sq = chess.square(f, r)
        if self.selected is not None:
            move = chess.Move(self.selected, sq)
            p = self.board.piece_at(self.selected)
            if p and p.piece_type == chess.PAWN and r in (0, 7):
                move.promotion = chess.QUEEN
            if move in self.board.legal_moves:
                self.push(move)
                return
        p = self.board.piece_at(sq)
        self.selected = sq if p and p.color == self.board.turn and sq != self.selected else None
        self.draw()

    # ---- buttons ---------------------------------------------------------
    def play_suggestion(self):
        if self.suggestion:
            self.push(self.suggestion)

    def undo(self):
        if self.board.move_stack:
            self.board.pop()
            self.selected = None
            self.refresh()

    def flip(self):
        self.flipped = not self.flipped
        self.draw()

    def new_game(self, ask=False):
        ans = simpledialog.askstring(
            "New game", "Which colour are you playing? (white / black)",
            initialvalue="white", parent=self.root)
        if ans is None and ask:
            ans = "white"
        if ans is None:
            return
        self.my_color = chess.BLACK if ans.strip().lower().startswith("b") else chess.WHITE
        self.flipped = self.my_color == chess.BLACK
        self.board = chess.Board()
        self.selected = None
        self.refresh()

    def quit(self):
        self.advisor.close()
        self.root.destroy()


def main():
    ap = argparse.ArgumentParser(description="Chess move advisor")
    ap.add_argument("--stockfish", help="path to a Stockfish executable")
    ap.add_argument("--time", type=float, default=1.0,
                    help="seconds Stockfish thinks per move (default 1.0)")
    args = ap.parse_args()

    advisor = Advisor(args.stockfish, args.time)
    root = tk.Tk()
    App(root, advisor)
    root.title(f"Chess Move Advisor — {advisor.name}")
    root.mainloop()


if __name__ == "__main__":
    main()
